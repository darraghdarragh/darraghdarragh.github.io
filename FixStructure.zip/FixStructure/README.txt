Darragh Morrissey
Date: 16.10.2025

This project is my Code Challenge submission.
It includes:
- index.html (Cover Letter)
- experience.html (Experience, Skills & Education)
- styles/style.css (stylesheet)
- images/darragh.jpg (profile image)

Relative pathing:
  - styles/style.css
  - images/darragh.jpg
  - experience.html / index.html links

Absolute pathing:
  - LinkedIn: https://www.linkedin.com/in/darragh-morrissey-71315724a